
function O = RCSMOTE(BS,N,r,k,T)  

Syn=[];
P_max=max(BS);
N_min=min(N);
Range=(P_max + N_min)/2;

BSnn=nearestneighbour(T', BS', 'NumberOfNeighbours', k+1);
BSnn(1,:) = []; 
Nnn = nearestneighbour(T', N', 'NumberOfNeighbours', k);

Synthetic=populate(r,BSnn,Nnn,Range,P_max,BS,N);
O=[Syn;Synthetic];   

end

function [Border,Safe,Noise]=Categorize(I,N,P,k)

original_features=I(:,1:end-1);
original_mark=I(:,end);
P_index = find(original_mark == 1);

P_neighbors = nearestneighbour(P', original_features', 'NumberOfNeighbours', k+1);
P_neighbors(1,:) = [];
num_N_neighbor = zeros(1,length(P_index));
for i=1:length(P_index)
    for j = 1:k
        if(original_mark(P_neighbors(j,i),1)== 0) 
            num_N_neighbor(1,i) = num_N_neighbor(1,i)+1;
        end
    end
end

Noise_index = P_index(find(num_N_neighbor == k),1);

Border_index = P_index(find((k/2 <= num_N_neighbor) & ( num_N_neighbor < k)),1);

Safe_index=P_index(find(num_N_neighbor < k/2),1);

Border = original_features(Border_index,:);
disp(['      Number of Border Samples: ', num2str(size(Border,1))]);

Safe = original_features(Safe_index,:);
disp(['      Number of Safe Samples: ', num2str(size(Safe,1))]);

Noise = original_features(Noise_index,:);
disp(['      Number of Noise Samples: ', num2str(size(Noise,1))]);

end
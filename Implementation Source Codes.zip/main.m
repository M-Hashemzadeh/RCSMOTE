
% Help:
% The input dataset should be in .xlsx format.

% The last column of the input dataset should be the class lable where "0" 
%    is used as majority class lable and "1" is used for minority class.

% Ready-to-process version of the tested datasets are available in the
%    "InputData" folder (in Excel file format).

% To process each dataset, simply paste the Excel file name into the
% command "xlsread" in this main file (row 23). For example, to process 
% the "Bupa" dataset, this command should be as "I = xlsread('InputData\Bupa.xlsx');"

% The output balanced data will be saved into "OutputData" folder in .mat
%    format.

clc;
clear all;
disp('Program started:');

disp('   Reading the input dataset...');
I = xlsread('InputData\Bupa.xlsx');   % Input imbalanced dataset I

% Stage 1
disp('   Separating minority and majority class samples...');
[P,N]=SeparateMinorityMajorityClasses(I);

% Stage 2
disp('   Identifying border, safe and noisy minority samples...');
[Border,Safe,Noise]=Categorize(I,N,P,3);
BS = [Border;Safe];  % Minority features without noise 
fdnum1=size(P,1);
fdnum0=size(N,1);
final_data=[];
final_data=[final_data,I];

% Stage 3
disp('   RCSMOTE Oversampling...');
if(size(Border,1)>0)
    
     r=ceil((size(N,1)-size(P,1))/size(Border,1))*100; % Calculating the required amount(percentage)of oversampling of each sample. Similar to the basic SMOTE algorithm it is assumed to be in integral multiples of 100 {100%, 200%, 300%, 400%, 500%}.
     if(r>500)
         r=500; 
     end
     
     Border_Syn = RCSMOTE(BS,N,r,5,Border);
     
     final_data=[final_data;Border_Syn];
     fdnum1=size(find(final_data(:,end) == 1),1);
     fdnum0=size(find(final_data(:,end)== 0),1);
end
if ( fdnum1<fdnum0 && size(Safe,1)>0 )
    
     r=floor((fdnum0-fdnum1)/size(Safe,1))*100;  
     
     Safe_Syn = RCSMOTE(BS,N,r,5,Safe);
     
     final_data=[final_data;Safe_Syn];
     fdnum1=size(find(final_data(:,end) == 1),1);
     fdnum0=size(find(final_data(:,end)== 0),1);    
end 

% Saving the results.
save('OutputData\finaldata','final_data');

disp('Processing was completed, and the dataset was balanced and saved into "OutputData" folder.');

% /*Function to generate the synthetic samples.*/
function Synthetic=populate(r,BSnn,Nnn,Range,P_max,BS,N )

Synthetic_mark=[];
Synthetic_feature=[];

for sample=1:size(BSnn,2)
   
   M=floor(r/100);
   while M~=0 
        rn = ceil(rand(1)*size(BSnn,1));
        s1_index = BSnn(rn,sample);
        s2_index = Nnn(rn,sample);
        s1 = BS(s1_index,:);
        s2 = N(s2_index,:);

        for attr=1:size(s1,2)

              if (s1(1,attr)< s2(1,attr))
                     Min_value(1,attr)= s1(1,attr);
              else
                     Min_value(1,attr)= s2(1,attr);  
              end    
        end                   

        Diff =P_max - Min_value;                   
        gap=rand();
        while gap<0.5
              gap=rand(); 
        end

        Var = gap.*Diff ;
        snew=Min_value+ Var;

        for attr=1:size(s1,2)                   
              if (snew(1,attr) > Range(1,attr))
                   snew(1,attr)= P_max(1,attr)-Var(1,attr);                           
              end                            
        end                 

        Synthetic_mark=[Synthetic_mark;1];
        Synthetic_feature=[Synthetic_feature;snew];

        M=M-1;                   
   end 
end
 Synthetic = [Synthetic_feature,Synthetic_mark]; 
end

                   
                 

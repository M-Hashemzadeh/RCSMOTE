
function [P,N]=SeparateMinorityMajorityClasses(I)

original_features=I(:,1:end-1);
original_mark=I(:,end);

P_num=size( find(original_mark == 1),1);
% The minority class lable is 1;

N_num=size( find(original_mark == 0),1);
% The majority class lable is 0;

P_index = find(original_mark == 1);
N_index = find(original_mark == 0);

P = original_features(P_index,:);
N = original_features(N_index,:);

end